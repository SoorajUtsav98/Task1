import './App.css';
import DisplayPage from "./DisplayPage/DisplayPage";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <DisplayPage/>
      </header>
    </div>
  );
}

export default App;
