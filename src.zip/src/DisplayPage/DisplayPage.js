import Header from "../Header/Header";
import MainParent from "../MainParent/MainParent";

function DisplayPage (){
    
        return(
            <div>
             <Header/>
             <MainParent/>
           </div>
        );
    
}

export default DisplayPage;